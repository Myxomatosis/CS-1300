# Lab 1: Practice running a program and uploading to Moodle
# Author Luciano Mejia
# Version Fall 2014
a = 7;
b = 3;
print(a+b)
